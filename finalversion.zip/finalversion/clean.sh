#!/bin/bash
rm everything* filtered*
